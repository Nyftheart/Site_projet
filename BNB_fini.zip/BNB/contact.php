<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <!-- Titre -->
    <title>Dorne - Directory &amp; Listing Template | Contact</title>

    <!-- icon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- lien css -->
    <link href="style.css" rel="stylesheet">

    <!-- responsive css -->
    <link href="css/responsive/responsive.css" rel="stylesheet">

</head>

<body>
    <!-- chargement -->
    <div id="preloader">
        <div class="dorne-load"></div>
    </div>



    <!-- ***** entete ***** -->
    <header class="header_area" id="header">
        <div class="container-fluid h-100">
            <div class="row h-100">
                <div class="col-12 h-100">
                    <nav class="h-100 navbar navbar-expand-lg">
                        <a class="navbar-brand" href="index.php"><img src="img/core-img/logo.png" alt=""></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#dorneNav" aria-controls="dorneNav" aria-expanded="false" aria-label="Toggle navigation"><span class="fa fa-bars"></span></button>
                        
                        <div class="collapse navbar-collapse" id="dorneNav">
                            <ul class="navbar-nav mr-auto" id="dorneMenu">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item dropdown">
                                        <a class="nav-link" href="listing.php">Annonces</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.php">Contact</a>
                                </li>
                            </ul>
                          
                            <div class="dorne-add-listings-btn">
                                <a href="Ajout2.php" class="btn dorne-btn">+ Ajouter des annonces</a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** entete fin ***** -->

    
    <div class="breadcumb-area bg-img bg-overlay" style="background-image: url(img/bg-img/hero-1.jpg)">
    </div>
    


    <div class="dorne-contact-area d-md-flex" id="contact">

        <div class="contact-form-area equal-height">
            <div class="contact-text">
                <h4>Donner votre resenti</h4>
                <div class="contact-info d-lg-flex">
                    <div class="single-contact-info">
                        <h6><i class="fa fa-map-signs" aria-hidden="true"></i>Chemin de traverse</h6>
                        <h6><i class="fa fa-map-signs" aria-hidden="true"></i>Quai 9 3/4</h6>
                    </div>
                    <div class="single-contact-info">
                        <h6><i class="fa fa-envelope-o" aria-hidden="true"></i>DonneTaTune@hackdebanque.com</h6>
                        <h6><i class="fa fa-phone" aria-hidden="true"></i>0615031040</h6>
                    </div>
                </div>
            </div>
            <div class="contact-form">
                <div class="contact-form-title">
                    <h6>Contact Entreprise</h6>
                </div>
                <form action="#">
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <input type="text" name="name" class="form-control" placeholder="Votre Nom">
                        </div>
                        <div class="col-12 col-md-6">
                            <input type="email" name="email" class="form-control" placeholder="Email">
                        </div>
                        <div class="col-12">
                            <input type="text" name="subject" class="form-control" placeholder="Suget">
                        </div>
                        <div class="col-12">
                            <textarea name="message" class="form-control" id="Message" cols="30" rows="10" placeholder="Votre Message"></textarea>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn dorne-btn">Envoyer</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="dorne-map-area equal-height">
                   </div>
    </div>





    <!-- ****** footer ****** -->
    <footer class="dorne-footer-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 d-md-flex align-items-center justify-content-between">
                    <div class="footer-text">
                        <p>
                            
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Fait avec le  <i class="fa fa-heart-o" aria-hidden="true"></i>

                        </p>
                    </div>
                    <div class="footer-social-btns">
                        <a href="#"><i class="fa fa-twitter" aria-haspopup="true"></i></a>
                        <a href="#"><i class="fa fa-facebook" aria-haspopup="true"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ****** footer fin ****** -->

    <!-- jQuery -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- Plugins -->
    <script src="js/others/plugins.js"></script>
    <!-- Active -->
    <script src="js/active.js"></script>
</body>

</html>