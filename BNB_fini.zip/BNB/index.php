<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <!-- Titre -->
    <title>Dorne</title>

    <!-- icon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- lien css -->
    <link href="style.css" rel="stylesheet">

    <!-- responsive css -->
    <link href="css/responsive/responsive.css" rel="stylesheet">

</head>

<body>
    <!-- chargement  -->
    <div id="preloader">
        <div class="dorne-load"></div>
    </div>



    <!-- ***** entete ***** -->
    <header class="header_area" id="header">
        <div class="container-fluid h-100">
            <div class="row h-100">
                <div class="col-12 h-100">
                    <nav class="h-100 navbar navbar-expand-lg">
                        <a class="navbar-brand" href="index.php"><img src="img/core-img/logo.png" alt=""></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#dorneNav" aria-controls="dorneNav" aria-expanded="false" aria-label="Toggle navigation"><span class="fa fa-bars"></span></button>
                        <!-- Nav -->
                        <div class="collapse navbar-collapse" id="dorneNav">
                            <ul class="navbar-nav mr-auto" id="dorneMenu">
                                <li class="nav-item active">
                                    <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item dropdown">  
                                        <a class="nav-link" href="listing.php">Annonce</a>
                                </li>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.php">Contact</a>
                                </li>
                            </ul>
                            <!-- Add listings btn -->
                            <div class="dorne-add-listings-btn">
                                <a href="Ajout2.php" class="btn dorne-btn">+ Ajouter des annonces</a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** entete fin ***** -->

    <!-- ***** corp ***** -->
    <section class="dorne-welcome-area bg-img bg-overlay" style="background-image: url(img/bg-img/hero-1.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center justify-content-center">
                <div class="col-12 col-md-10">
                    <div class="hero-content">
                        <h2>Découvrez des endroits près de chez vous</h2>
                        <h4>Ceci est le meilleur guide de votre ville</h4>
                    </div>
                    <!-- recherche  -->
                    <div class="hero-search-form">
                        
                        <div class="nav nav-tabs" id="heroTab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-places-tab" data-toggle="tab" href="#nav-places" role="tab" aria-controls="nav-places" aria-selected="true">Places</a>
                        </div>
                        
                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="nav-places" role="tabpanel" aria-labelledby="nav-places-tab">
                                <h6>Que cherchez-vous?</h6>
                                <form action="listing2.php" method="get">
                                    <select class="custom-select"  name="pays" id='pays'>
                                        <option selected>Destinations</option>
                                        <option value="Paris">Paris</option>
                                        <option value="New York" >New York</option>
                                        <option value="Ibiza" >Ibiza</option>
                                        <option value="4" >Melbourne</option>
                                        <option value="5" >London</option>
                                    </select>
                                    <select class="custom-select" name="type" id='type'>
                                        <option selected>Categories</option>
                                        <option value="Campagne">Campagne</option>
                                        <option value="Ville">Villes</option>
                                    </select>
                                    <select class="custom-select" name="prix" id='prix'>
                                        <option selected>Prix Maximal</option>
                                        <option value="600">600€</option>
                                        <option value="800">800€</option>
                                        <option value="999">999€</option>
                                    </select>
                                    <button type="submit" class="btn dorne-btn"><i class="fa fa-search pr-2" aria-hidden="true"></i>Recherche</button>
                                </form>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- bouton social -->
        <div class="hero-social-btn">
            <div class="social-title d-flex align-items-center">
                <h6>Suiver nous sur les Reseau</h6>
                <span></span>
            </div>
            <div class="social-btns">
                <a href="#"><i class="fa fa-twitter" aria-haspopup="true"></i></a>
                <a href="#"><i class="fa fa-facebook" aria-haspopup="true"></i></a>
            </div>
        </div>
    </section>



    <section class="dorne-catagory-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="all-catagories">
                        <div class="row">
                            <!-- idice -->
                            <div class="col-12 col-sm-6 col-md">
                                <div class="single-catagory-area wow fadeInUpBig" data-wow-delay="0.2s">
                                    <div class="catagory-content">
                                        <img src="img/core-img/icon-1.png" alt="">
                                        <a href="#">
                                            <h6>Hotels Et Maisons</h6>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ***** pharse sepa ***** -->
    <section class="dorne-about-area section-padding-0-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="about-content text-center">
                        <h2>DÉCOUVREZ VOTRE VILLE AVEC<br><span>Dorne</span></h2>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** fin phrase sepa ***** -->

    <!-- ***** ville simple ***** -->
    <section class="dorne-editors-pick-area bg-img bg-overlay-9 section-padding-100" style="background-image: url(img/bg-img/hero-2.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading text-center">
                        <span></span>
                        <h4>VILLES À VOIR</h4>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 col-lg-6">
                    <div class="single-editors-pick-area wow fadeInUp" data-wow-delay="0.2s">
                        <img src="img/bg-img/editor-1.jpg" alt="">
                        <div class="editors-pick-info">
                            <div class="places-total-destinations d-flex">
                                <a href="#">New York</a>
                                <a href="#">1643 Destinations</a>
                            </div>
                            <div class="add-more">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="single-editors-pick-area wow fadeInUp" data-wow-delay="0.4s">
                        <img src="img/bg-img/editor-2.jpg" alt="">
                        <div class="editors-pick-info">
                            <div class="places-total-destinations d-flex">
                                <a href="#">Barcelona</a>
                                <a href="#">943 Destinations</a>
                            </div>
                            <div class="add-more">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="single-editors-pick-area wow fadeInUp" data-wow-delay="0.6s">
                        <img src="img/bg-img/editor-3.jpg" alt="">
                        <div class="editors-pick-info">
                            <div class="places-total-destinations d-flex">
                                <a href="#">paris</a>
                                <a href="#">243 Destinations</a>
                            </div>
                            <div class="add-more">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** ville simple fin  ***** -->

    <!-- ***** destination (slider) ***** -->
    <section class="dorne-features-destinations-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading dark text-center">
                        <span></span>
                        <h4>Meilleur Destinations</h4>
                    </div>
                </div>
            </div>
            <?php
            $pdo = new PDO("mysql:host=localhost;dbname=bnb", "root", "" , array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
            $result = $pdo->query("SELECT * FROM annonce");?>

            <div class="row">
                <div class="col-12">
                    <div class="features-slides owl-carousel">
                    <?php while($info = $result->fetch(PDO::FETCH_OBJ)) {?>
                       
                        <div class="single-features-area">
                        <form method="POST" action="" enctype="multipart/form-data">
                        <a href="Page.php?id=<?php echo $info->id_annonce?>"><img src="<?php echo $info->cheminImg ?>" alt=""></a>
                        </form>
                           
                            <div class="price-start">
                                <p>A Partir <?php echo $info->prix ?>€/Nuit</p>
                            </div>
                            <div class="feature-content d-flex align-items-center justify-content-between">
                                <div class="feature-title">
                                    <h5><?php echo $info->pays ?></h5>
                                    <p><?php echo $info->message ?></p>
                                </div>
                                <div class="feature-favourite">
                                    <a href="#"><i class="fa fa-heart-o" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** destination fin  ***** -->

    

    <!-- ****** footer ****** -->
    <footer class="dorne-footer-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 d-md-flex align-items-center justify-content-between">
                    <div class="footer-text">
                        <p>
                           
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Fait avec le <i class="fa fa-heart-o" aria-hidden="true"></i>

                        </p>
                    </div>
                    <div class="footer-social-btns">
                        <a href="#"><i class="fa fa-twitter" aria-haspopup="true"></i></a>
                        <a href="#"><i class="fa fa-facebook" aria-haspopup="true"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ****** footer fin ****** -->

    <!-- jQuery -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- Plugins -->
    <script src="js/others/plugins.js"></script>
    <!-- Active  -->
    <script src="js/active.js"></script>
</body>

</html>
<!-- c'est fini -->