<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Titre -->
    <title>Dorne - Directory &amp; Listing Template | Listing</title>

    <!-- icon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- lien css -->
    <link href="style.css" rel="stylesheet">

    <!-- responsive css -->
    <link href="css/responsive/responsive.css" rel="stylesheet">

</head>

<body>
    <!-- chargement -->
    <div id="preloader">
        <div class="dorne-load"></div>
    </div>



    <!-- ***** entete ***** -->
    <header class="header_area" id="header">
        <div class="container-fluid h-100">
            <div class="row h-100">
                <div class="col-12 h-100">
                    <nav class="h-100 navbar navbar-expand-lg">
                        <a class="navbar-brand" href="index.php"><img src="img/core-img/logo.png" alt=""></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#dorneNav" aria-controls="dorneNav" aria-expanded="false" aria-label="Toggle navigation"><span class="fa fa-bars"></span></button>
                       
                        <div class="collapse navbar-collapse" id="dorneNav">
                            <ul class="navbar-nav mr-auto" id="dorneMenu">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item dropdown">
                                        <a class="nav-link" href="listing.php">Annonces</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.php">Contact</a>
                                </li>
                            </ul>

                           
                            <div class="dorne-add-listings-btn">
                                <a href="Ajout2.php" class="btn dorne-btn">+ Ajouter des annonces</a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** entete fin ***** -->


    <div class="breadcumb-area bg-img bg-overlay" style="background-image: url(img/bg-img/hero-1.jpg)"></div>



    <section class="dorne-listing-destinations-area section-padding-100-50">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading dark text-center">
                        <span></span>
                        <h4>Meilleur destination</h4>
                    </div>
                </div>
            </div>
            <?php
            $pdo = new PDO("mysql:host=localhost;dbname=bnb", "root", "" , array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
            $result = $pdo->query("SELECT * FROM annonce WHERE pays = '$_GET[pays]' AND type='$_GET[type]' AND prix <= '$_GET[prix]'");?>
            
            <div class="row">
            <?php while($info = $result->fetch(PDO::FETCH_OBJ)) {?>
  
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-features-area mb-50">
                        <form method="POST" action="" enctype="multipart/form-data">
                        <a href="Page.php?id=<?php echo $info->id_annonce?>" type="submit"><img src="<?php echo $info->cheminImg ?>" alt=""></a>
                        </form>

                        <div class="price-start">
                            <p>A Partir <?php echo $info->prix ?>€/Nuit</p>
                        </div>
                        <div class="feature-content d-flex align-items-center justify-content-between">
                            <div class="feature-title">
                                <h5><?php echo $info->pays ?></h5>
                                <p><?php echo $info->message ?></p>
                            </div>
                            <div class="feature-favourite">
                                <a href="#"><i class="fa fa-heart-o" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <?php 
                 } ?>
                
                </div>
            </div>
        </div>
    </section>


    <!-- ****** footer ****** -->
    <footer class="dorne-footer-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 d-md-flex align-items-center justify-content-between">
                    <div class="footer-text">
                        <p>
                            
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Fait avec le <i class="fa fa-heart-o" aria-hidden="true"></i>

                        </p>
                    </div>
                    <div class="footer-social-btns">
                        <a href="#"><i class="fa fa-twitter" aria-haspopup="true"></i></a>
                        <a href="#"><i class="fa fa-facebook" aria-haspopup="true"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ****** footer fin ****** -->

    <!-- jQuery -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- Plugins -->
    <script src="js/others/plugins.js"></script>
    <!-- Active -->
    <script src="js/active.js"></script>
</body>

</html>