<?php ini_set('display_errors','off'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   
    <!-- Titre -->
    <title>Dorne - Directory &amp; Listing Template | Contact</title>

    <!-- icon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- lien css -->
    <link href="style.css" rel="stylesheet">

    <!-- responsive css -->
    <link href="css/responsive/responsive.css" rel="stylesheet">

</head>

<body>
    <!-- chargement -->
    <div id="preloader">
        <div class="dorne-load"></div>
    </div>



    <!-- ***** entete ***** -->
    <header class="header_area" id="header">
        <div class="container-fluid h-100">
            <div class="row h-100">
                <div class="col-12 h-100">
                    <nav class="h-100 navbar navbar-expand-lg">
                        <a class="navbar-brand" href="index.php"><img src="img/core-img/logo.png" alt=""></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#dorneNav" aria-controls="dorneNav" aria-expanded="false" aria-label="Toggle navigation"><span class="fa fa-bars"></span></button>
                        
                        <div class="collapse navbar-collapse" id="dorneNav">
                            <ul class="navbar-nav mr-auto" id="dorneMenu">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item dropdown">
                                        <a class="nav-link" href="listing.php">Annonces</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.php">Contact</a>
                                </li>
                            </ul>
                        
                            <div class="dorne-add-listings-btn">
                                <a href="#" class="btn dorne-btn">+ Ajouter des annonces</a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** entete fin ***** -->
    <?php
$pdo = new PDO("mysql:host=localhost;dbname=bnb", "root", "", array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
//***************************************** */
//Enregistrement du nouveau bien
//***************************************** */
if (!empty($_POST)) {

    $name = "";
    if (!empty($_FILES)) {

        foreach ($_FILES["img"]["error"] as $key => $error) {
            if ($error == UPLOAD_ERR_OK) {
                $tmp_name = $_FILES["img"]["tmp_name"][$key];
                $name = basename($_FILES["img"]["name"][$key]);
                move_uploaded_file($tmp_name, "img/$name");
            }
        }

    }

    //*********************************************** */
    // Insetion
    $sql = "INSERT INTO annonce (pays, email, cheminImg, prix, message, type) VALUES ('$_POST[pays]', '$_POST[email]', 'img/$name', '$_POST[prix]', '$_POST[message]', '$_POST[type]');";
    $result = $pdo->exec($sql);
    //*********************************************** */

}

?>
    
    <div class="breadcumb-area bg-img bg-overlay" style="background-image: url(img/bg-img/hero-1.jpg)">
    </div>
   

    
    <div class="dorne-contact-area d-md-flex" id="contact">
       
        <div class="contact-form-area equal-height">
            <div class="contact-text">
                <h4>Ajout de bien</h4>
            </div>
            <div class="contact-form">
                <div class="contact-form-title">
                </div>
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <input type="text" name="pays" class="form-control" placeholder="Ville" id='pays'>
                        </div>
                        <div class="col-12 col-md-6">
                            <input type="email" name="email" class="form-control" placeholder="Email" id='email'>
                        </div>
                        <div class="col-12">
                            <input type="Number" name="prix" class="form-control" placeholder="Prix" id='prix'>
                        </div>
                        <div class="col-12">
                            <textarea name="message" class="form-control" id="message" cols="30" rows="10" placeholder="Votre Message" id='message'></textarea>
                        </div>
                        <div class="col-12">
                            <input type="text" name="type" class="form-control" placeholder="Campagne ou Ville" id='type'>
                        </div>
                        <div class="col-12">
                            <label for="titre">Image</label>
                            <input type="file" class="form-control" id="img" name="img[]">
                         </div>

                        <div class="col-12">
                            <button type="submit" class="btn dorne-btn">+ Ajouter</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="dorne-map-area equal-height">
                   </div>
    </div>
   
    <div class="col-12">
        <p>Supprimer une annonce cliqué <a href="Sup.php">ICI</a></p>                 
    </div>
    <!-- ****** footer ****** -->
    <footer class="dorne-footer-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 d-md-flex align-items-center justify-content-between">
                    <div class="footer-text">
                        <p>
                            
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Fait avec le  <i class="fa fa-heart-o" aria-hidden="true"></i>

                        </p>
                    </div>
                    <div class="footer-social-btns">
                        <a href="#"><i class="fa fa-twitter" aria-haspopup="true"></i></a>
                        <a href="#"><i class="fa fa-facebook" aria-haspopup="true"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ****** footer fin ****** -->


    <!-- jQuery -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- Plugins -->
    <script src="js/others/plugins.js"></script>
    <!-- Active -->
    <script src="js/active.js"></script>
</body>

</html>